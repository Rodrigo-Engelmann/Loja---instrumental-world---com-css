function validateDropdown(){
    alert("Informações adicionadas ao histórico de vendas")
}